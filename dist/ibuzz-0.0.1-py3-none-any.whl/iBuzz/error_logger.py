def log_error(error):
    print("error received by error logger: ", error)


class ErrorLogger:
    pass
